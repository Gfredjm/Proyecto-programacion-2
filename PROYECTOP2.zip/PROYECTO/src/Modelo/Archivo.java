/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Alfredo Maestre
 */
public class Archivo {

    public static void guardarContacto(ArrayList<Contacto> listaContactos) throws IOException {
        try {
            File f = new File( "Contactos.txt");
            FileWriter fw = new FileWriter(f, true);
            for (Contacto contacto : listaContactos) {
                fw.write(contacto.getNombre() + "$" + contacto.getTelefono() + "$"
                        + contacto.getDireccion() + "$" + contacto.getEmail() + "\n");
            }
            fw.close();
        } catch (IOException ex) {
            // Manejar la excepción de alguna manera (imprimir mensaje, log, etc.)
            ex.printStackTrace();
        }
    }

    public static ArrayList<Contacto> leerContactos(String nombreArchivo) {
        ArrayList<Contacto> listaContactos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] atributos = linea.split("[$]");
                if (atributos.length == 4) {
                    Contacto contacto = new Contacto(atributos[0], atributos[1], atributos[2], atributos[3]);
                    listaContactos.add(contacto);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al leer desde el archivo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return listaContactos;
    }

//esta funcion sobre escribe el archivo
    public static void eliminarContacto(ArrayList<Contacto> listaContactos) throws IOException {
        File archivo = new File(".");
        File f = new File(archivo, "Contactos.txt");

        FileWriter fw = new FileWriter(f);
        BufferedWriter bw = new BufferedWriter(fw);

        for (Contacto contacto : listaContactos) {
            bw.write(contacto.getNombre() + "$" + contacto.getTelefono() + "$"
                    + contacto.getDireccion() + "$" + contacto.getEmail() + "\n");
        }
        bw.close();
    }

    /*
 if (nombreExistente.equals(txtEditNomb.getText().trim()) && !telefonoExistente.equals(txtEditTele.getText().trim())) {
            if (!telefonoExistenEnJTable(nuevoTelefono)) {
                model.setValueAt(nuevoNombre, filaSeleccionada, 0);
                model.setValueAt(nuevoTelefono, filaSeleccionada, 1);
                model.setValueAt(nuevoDireccion, filaSeleccionada, 2);
                model.setValueAt(nuevoEmail, filaSeleccionada, 3);

                // Actualiza el ArrayList con los nuevos datos
                actualizarDatosEnLista(filaSeleccionada, nuevoNombre, nuevoTelefono, nuevoDireccion, nuevoEmail);
            } else {
                JOptionPane.showMessageDialog(null, "El usuario decidió dejar el mismo nombre", "Datos no modificados", JOptionPane.INFORMATION_MESSAGE);

            }
        } else if (!nombreExistente.equals(nuevoNombre) && telefonoExistente.equals(nuevoTelefono)) {
            if (!nombreExistenEnJTable(nuevoNombre)) {
                model.setValueAt(nuevoNombre, filaSeleccionada, 0);
                model.setValueAt(nuevoTelefono, filaSeleccionada, 1);
                model.setValueAt(nuevoDireccion, filaSeleccionada, 2);
                model.setValueAt(nuevoEmail, filaSeleccionada, 3);

                // Actualiza el ArrayList con los nuevos datos
                actualizarDatosEnLista(filaSeleccionada, nuevoNombre, nuevoTelefono, nuevoDireccion, nuevoEmail);
            } else {
                JOptionPane.showMessageDialog(null, "El usuario decidió dejar el mismo teléfono", "Datos no modificados", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (nombreExistente.equals(nuevoNombre) && telefonoExistente.equals(nuevoTelefono)) {
            JOptionPane.showMessageDialog(null, "No se realizaron cambios en los datos", "Datos no modificados", JOptionPane.INFORMATION_MESSAGE);
        } else if (!datosExistenEnJTable(nuevoNombre, nuevoTelefono)) {
            // Los nuevos datos no existen, realiza la modificación en la JTable
            model.setValueAt(nuevoNombre, filaSeleccionada, 0);
            model.setValueAt(nuevoTelefono, filaSeleccionada, 1);
            model.setValueAt(nuevoDireccion, filaSeleccionada, 2);
            model.setValueAt(nuevoEmail, filaSeleccionada, 3);
            actualizarDatosEnLista(filaSeleccionada, nuevoNombre, nuevoTelefono, nuevoDireccion, nuevoEmail);
        } else {
            JOptionPane.showMessageDialog(null, "Los datos ya existen en la JTable", "Datos Repetidos", JOptionPane.ERROR_MESSAGE);
        }
     */
}
