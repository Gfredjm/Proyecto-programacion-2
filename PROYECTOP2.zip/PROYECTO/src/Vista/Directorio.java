package Vista;

import Modelo.Archivo;
import Modelo.Contacto;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Directorio extends javax.swing.JFrame {

    private int filaSeleccionada;
    private ArrayList<Contacto> contactos = new ArrayList();
    private DefaultTableModel tableModel;

    public Directorio() {
        initComponents();
        this.setLocationRelativeTo(null);
        cargarTablaInicioSesion();
    }

    //la siguente funcion carga en la tabla, los datos almacenados en el archivo cuando este jframe se inicializa
    public void cargarTablaInicioSesion() {
        //aqui carga el array con los datos que hay en el archivo llamando a la funcion statica leerContactos de la calase Archivo
        contactos = Archivo.leerContactos("Contactos.txt");

        //valida que se lea el archivo correctamente y carga la tabla
        if (!contactos.isEmpty()) {
            //defaultTableModel obtiene el modelo de la tabla, identificandola por el nombre que le asignamos(jtbContactos)
            DefaultTableModel model = (DefaultTableModel) jtbContactos.getModel();
            //recorre la lista con un ciclo for
            for (Contacto c : contactos) {
                //cargamos los datos en un objeto
                Object[] datos = {c.getNombre(), c.getTelefono(), c.getDireccion(), c.getEmail()};
                //cargamos la tabla con los datos almacenados en el object
                model.addRow(datos);
            }
        }
    }

    //esta Funcion limpia los jtexfiel
    void limpiar() {
        txtNombre.setText("");
        txtTelefono.setText("");
        txtDireccion.setText("");
        txtEmail.setText("");
        txtEditDir.setText("");
        txtEditTele.setText("");
        txtEditEmail.setText("");
        txtEditNomb.setText("");
    }

    // Función para actualizar la JTable con la información del array de contactos
    private void actualizarTabla() {
        //obtiene el modelo de la tabla identificada como jtbContactos
        DefaultTableModel model = (DefaultTableModel) jtbContactos.getModel();
        //model setRowCount(0)limpia las lineas de la tabla
        model.setRowCount(0); // Limpiar la tabla antes de agregar los nuevos datos

        // Iterar sobre la lista de contactos y agregar cada contacto a la tabla
        for (Contacto c : contactos) {
            //cargamos cada objeto de la lista en un objeto temporal   
            Object[] datos = {c.getNombre(), c.getTelefono(), c.getDireccion(), c.getEmail()};
            //y los carga a la tabla
            model.addRow(datos);
        }
    }

//la funcion agregar, crea un nuevo contacto y lo agrega a la lista 
    public void agregar() {
        // Primero se obtienen en variables temporales los datos ingresados en los JTextField
        String nombre = txtNombre.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String direccion = txtDireccion.getText().trim();
        String email = txtEmail.getText().trim();

        // Se verifica que los campos obligatorios no estén vacíos (nombre y teléfono)
        if (nombre.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nombre y Teléfono son obligatorios", "Datos Obligatorios", JOptionPane.ERROR_MESSAGE);
            return; // Se sale de la función si faltan datos obligatorios
        }

        // Validación de que el teléfono solo contiene números
        //se utiliza el metodo de la clase string matches, se utiliza para verificar cadenas de texto y dentro de los parametros 
        //le enviamos \\d+ es un patrón de expresión regular que coincide con cualquier dígito numérico (0-9)
        //en otras palabras estamos verificando que la cadena solo contenga caracteres entre el 0 y 9
        //!telefono esta convirtiendo la condicion es negativa
        if (!telefono.matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "El teléfono debe contener solo números", "Formato Incorrecto", JOptionPane.ERROR_MESSAGE);
            return; // Se sale de la función si el teléfono no es válido
        }

        // Se crea un nuevo objeto Contacto, y se carga con los datos almacenados en las variables
        Contacto contacto = new Contacto();
        contacto.setNombre(nombre);
        contacto.setTelefono(telefono);

        // Si el campo dirección está vacío, se asigna la cadena "null"
        contacto.setDireccion(direccion.isEmpty() ? "--" : direccion);

        // Si el campo email está vacío, se asigna la cadena "null"
        contacto.setEmail(email.isEmpty() ? "--" : email);

        // Se verifica si el contacto ya existe en la lista, la funcion de la linea de abajo devuelve un entero que puede ser -1 o mayor
        //si es -1 quiere decir que no encontro el objeto, si no,devuelve el entero con el numero de la posicion del objeto dentro de la lista 
        int contactoExistente = buscarContacto(nombre, telefono);
        if (contactoExistente == -1) {
            //  si no existe en la lista, se puede agregar , esta condicion valida que no hayan duplicados
            contactos.add(contacto);
            try {
                //una vez que se guardo en la lista procedemos a guardar los cambios en el archivo
                Archivo.guardarContacto(contactos);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error Al Registrar", "Error De Archivo", JOptionPane.ERROR_MESSAGE);
            }
            //llamamos a la funcion actualizar la tabla para que refresque la tabla con los cambios realizados
            actualizarTabla();
            // Se muestra un mensaje de éxito
            JOptionPane.showMessageDialog(null, "Contacto agregado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            // Se llama a la función limpiar para limpiar las cajas de texto
            limpiar();
        } else {
            // Si el contacto ya existe, se muestra un mensaje de error
            JOptionPane.showMessageDialog(null, "Ya Existe Un Contacto Con Estos Datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

// Función para buscar un contacto en la lista, decidimos manejar dos condiciones unicas para los contactos, el nombre y el telefono
//solo estos dos datos no deben estar repetidos
    private int buscarContacto(String nombre, String telefono) {
        //recorremos la lista en busca de coincidencia
        for (int i = 0; i < contactos.size(); i++) {
            //la condicion que manejamos es || que significa que si alguna de las dos condiciones no se cumple el resultado de la
            // operacion es falso , basados en la tabla de verdad
            if (contactos.get(i).getNombre().equalsIgnoreCase(nombre)
                    || contactos.get(i).getTelefono().equalsIgnoreCase(telefono)) {
                return i; // si algunas de las dos condiciones se cumple significa  que ese dato ya esta y devuelve el indice con la posicion del objeto en la lista
            }
        }
        return -1; // //si no estan los datos en la lista se devuelve -1 para decir que no esta 
    }

    //Esta funcion se encarga de eliminar un contacto de la lista, recibe un strin como parametro para compararlo con los nombres de los objetos almacenados en la lista
    public void eliminarContacto(String nombre) {
        //creamos una variable booleana para manejar la eliminacion mas adelante, la establecemos en false por cenveniencia
        boolean contactoEncontrado = false;
        //recorremos la lista de contactos 
        for (int i = 0; i < contactos.size(); i++) {
            //si en alguna de las iteracionde del ciclo la variable nombre que recibimos es igual a el atrubuto nombre del objeto
            if (contactos.get(i).getNombre().equalsIgnoreCase(nombre)) {
                //quiere decir que encontramos el objeto o contacto que vamos a eliminar
                //pero antes de eliminar validamos la decision con un show message confirm
                int opcion = JOptionPane.showConfirmDialog(
                        null,
                        "¿Estás seguro de que deseas eliminar el contacto: " + nombre + "?",
                        "Confirmar Eliminación",
                        JOptionPane.YES_NO_OPTION);
                // Si el usuario elige Sí, elimina el contacto
                if (opcion == JOptionPane.YES_OPTION) {
                    //se remueve de la lista el contacto 
                    contactos.remove(i);
                    JOptionPane.showMessageDialog(null, "Contacto Eliminado", "Eliminacion De Contacto", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        //una vez removido de la lista se actualiza el archivo
                        Archivo.eliminarContacto(contactos);
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null, "Error Al Eliminar El Archivo", "Error En El Archivo", JOptionPane.ERROR_MESSAGE);
                    }

                    //defaultable model nuevamente obtiene el modelo de la tabla
                    DefaultTableModel model = (DefaultTableModel) jtbContactos.getModel();
                    //la limpiamos 
                    model.setRowCount(0);
                    //y la cargamos actualizada, la funcion la reutilizamos porque se adapta a la necesidad de la situacion
                    cargarTablaInicioSesion();
                    return; // con el return cerramos la funcion
                    // si el usuario elige no entonces se cancela la eliminacion
                } else {
                    JOptionPane.showMessageDialog(null, "Eliminacion De Contacto Cancelada", "Contacto No Eliminado", JOptionPane.CANCEL_OPTION);
                }
                //si se elimino el contacto despues de encontrarlo se cambia el boleano a true
                contactoEncontrado = true;
            }
        }
        //si el boleano nunca se cambio a true quiere decir que no se encontro y mostramos el mensaje de que no se encontro el contacto
        if (!contactoEncontrado) {
            JOptionPane.showMessageDialog(null, "No Se Encontro El Contacto", "Contacto No Encontrado", JOptionPane.ERROR_MESSAGE);
        }
    }

    //esta funcion se encarga de seleccionar un contacto de la tabla de contactos directamente
    void editarContacto() {
        //si no se ha seleccionado en la tabla un contacto la funcion funcion selecrow devulve -1 y si es -1 pide que se seleccione alguna fila mediante un joptionpane
        if (jtbContactos.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "No Ha Seleccionado Un registro", "Seleccione Un Registro", JOptionPane.INFORMATION_MESSAGE);
        } else {
            //filaSeleccionada es una variable de tipo entero propia de este jframe, esta declaraada arriba, antes de los constructores de la clase
            //y almacena el numero de la linea que se selecciono en la tabla
            filaSeleccionada = jtbContactos.getSelectedRow();
            DefaultTableModel model = (DefaultTableModel) jtbContactos.getModel();
            //si ya se selecciono en la tabla algun contacto manda los datos de esa fila a las cajas de texto para posteriormente modificarlos si se desea
            txtEditNomb.setText(model.getValueAt(jtbContactos.getSelectedRow(), 0).toString());
            txtEditTele.setText(model.getValueAt(jtbContactos.getSelectedRow(), 1).toString());
            txtEditDir.setText(model.getValueAt(jtbContactos.getSelectedRow(), 2).toString());
            txtEditEmail.setText(model.getValueAt(jtbContactos.getSelectedRow(), 3).toString());
        }
    }

    //esta funcion es llamada cuando el usuario presiona el boton de modificar el contacto
    //se encarga de modificar el contacto seleccionado
    void modificar() {
        // Obtén el modelo de la tabla
        DefaultTableModel model = (DefaultTableModel) jtbContactos.getModel();

        // Obtén los nuevos datos de los campos de texto
        String nuevoNombre = txtEditNomb.getText();
        String nuevoTelefono = txtEditTele.getText();
        String nuevoDireccion = txtEditDir.getText();
        String nuevoEmail = txtEditEmail.getText();

        //esta validacion salta cuando no se ha seleccionado un contacto aun y se preodiona el boton confirmar
        if (nuevoNombre.isEmpty() && nuevoEmail.isEmpty() && nuevoDireccion.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Se Ha Seleccionado El Contacto Aún", "Contacto No Seleccionado", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        //ae valida que el nombre no este vacio
        if (nuevoNombre.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El Nombre No Puede Ser Vacío", "Datos Incorrectos", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verifica que los campos obligatorios no estén vacíos
        if (nuevoNombre.isEmpty() || nuevoTelefono.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Se Admiten Campos Vacíos", "Datos Incorrectos", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Verifica que el teléfono solo contenga números
        if (!nuevoTelefono.matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "El teléfono debe contener solo números", "Formato Incorrecto", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Asigna "--" a nuevoDireccion si está vacío
        nuevoDireccion = nuevoDireccion.isEmpty() ? "--" : nuevoDireccion;

        // Asigna "--" a nuevoEmail si está vacío
        nuevoEmail = nuevoEmail.isEmpty() ? "--" : nuevoEmail;

        // Obtiene los datos mas necesarios existentes antes de la modificación
        //getvalueat obtiene la posicion de la fila seleccionada
        //como se almacenara el dato en una cadena y la funcion devuelve un entero, lo pasamos a string con la funcion toString
        String nombreExistente = model.getValueAt(filaSeleccionada, 0).toString();

        // Verifica si los nuevos datos son diferentes de los existentes
        //si el usuario deja el mismo nombre, se carga la tabla con los demas datos y el nombre actual
        if (nombreExistente.equals(nuevoNombre)) {
            model.setValueAt(nombreExistente, filaSeleccionada, 0);
            model.setValueAt(nuevoTelefono, filaSeleccionada, 1);
            model.setValueAt(nuevoDireccion, filaSeleccionada, 2);
            model.setValueAt(nuevoEmail, filaSeleccionada, 3);
            limpiar();

            // Actualiza el ArrayList con los nuevos datos
            actualizarDatosEnLista(filaSeleccionada, nuevoNombre, nuevoTelefono, nuevoDireccion, nuevoEmail);
            JOptionPane.showMessageDialog(null, "Los datos Han Sido Actualizados", "Edición Exitosa", JOptionPane.INFORMATION_MESSAGE);

            //pero si el nombre no es igual tenemos que verificar que no se encuentre repetido en la tabla, para ello invocamos la funcion
            //datosExistenEnJTable que devuelve un booleano verdadero si lo encuentra o falso si no lo encuentra
        } else if (!datosExistenEnLaTabla(nuevoNombre)) {
            model.setValueAt(nuevoNombre, filaSeleccionada, 0);
            model.setValueAt(nuevoTelefono, filaSeleccionada, 1);
            model.setValueAt(nuevoDireccion, filaSeleccionada, 2);
            model.setValueAt(nuevoEmail, filaSeleccionada, 3);

            // Actualiza el ArrayList con los nuevos datos
            actualizarDatosEnLista(filaSeleccionada, nuevoNombre, nuevoTelefono, nuevoDireccion, nuevoEmail);
            JOptionPane.showMessageDialog(null, "Los datos Han Sido Actualizados", "Edición Exitosa", JOptionPane.INFORMATION_MESSAGE);
            // Limpia los campos de texto después de la modificación
            limpiar();
            //si nunca entra en las otras condiciones quiere decir que ya existe y no se podra modificar
        } else {
            JOptionPane.showMessageDialog(null, "Los datos ya existen en la JTable", "Datos Repetidos", JOptionPane.ERROR_MESSAGE);
        }
    }

    //esta funcion la utilizamos para actualizar la lista si se realiza la modificacion, para que los datos queden cambiados en la tabla y la lista
    private void actualizarDatosEnLista(int filaSeleccionada, String nuevoNombre, String nuevoTelefono, String nuevoDireccion, String nuevoEmail) {
        // Obtén el objeto Contacto de la lista en la posición correspondiente a la fila seleccionada
        //como la clase ya esta relacionada con el frame creamos una instancia de la clase objeto que inmediatamente igualamos 
        //a el objeto almacenado en la lista identificado por la variable filaSeleccionada que contiene la posicion donde se halla en la lista
        Contacto contactoSeleccionado = new Contacto();
        contactoSeleccionado = contactos.get(filaSeleccionada);

        // Actualiza los atributos del objeto Contacto con los nuevos datos
        contactoSeleccionado.setNombre(nuevoNombre);
        contactoSeleccionado.setTelefono(nuevoTelefono);
        contactoSeleccionado.setDireccion(nuevoDireccion);
        contactoSeleccionado.setEmail(nuevoEmail);

        //y actualizamos el archivo y aunque la funcion se llama eliminar contacto lo que hace es que sobre escribe el archivo con 
        //el array que le enviamos que ya esta actualizado asi que reutilizamos la funcion
        try {
            Archivo.eliminarContacto(contactos);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error Al Eliminar El Archivo", "Error En El Archivo", JOptionPane.ERROR_MESSAGE);
        }
        //nuevamente obtenemos el modelo de la tabla para limpiarla y cargarle la nueva lista actualizada
        DefaultTableModel model = (DefaultTableModel) jtbContactos.getModel();
        model.setRowCount(0);
        //aqui la cargamos 
        cargarTablaInicioSesion();

    }

    //esta funcion tiene como objetivo recorrer la lista y verificar si existe un contacto con el nombre que recibe como parametro
    void buscarContacto(String nombre) {
        int seEncontro = -1;
        for (int i = 0; i < contactos.size(); i++) {
            if (contactos.get(i).getNombre().equalsIgnoreCase(nombre)) {
                seEncontro = i;
                break;
            }
        }
        //si no lo encuentra  manda el respectivo mensaje por partalla
        if (seEncontro == -1) {
            JOptionPane.showMessageDialog(null, "No Se Encontro El Contacto", "Contacto No Encontrado", JOptionPane.ERROR_MESSAGE);
        } else {
            //si encontro inicializa el frame de informacion para mostrar la informacion del contacto, mandandole como parametro el contacto en cuestion
            new InfoContacto(contactos.get(seEncontro)).setVisible(true);

        }
    }

    //esta funcion esta destinada a recorrer todos los nombres de la tabla para saber si se encuenta el nombre que recibe como parametro
    //esta es una funcion auxiliar de la funcion modificar
    private boolean datosExistenEnLaTabla(String nombre) {
        //el for recorre el tamaño de la tabla
        for (int i = 0; i < jtbContactos.getRowCount(); i++) {
            //aqui se especifica que solo necesitamos recorrer la columna 0 que es la que contiene todos los nombres
            String nombreEnTabla = jtbContactos.getValueAt(i, 0).toString();
            String telefonoEnTabla = jtbContactos.getValueAt(i, 1).toString();

            if (nombreEnTabla.equals(nombre)) {
                return true; // Los datos ya existen en la JTable
            }
        }
        return false; // Los datos no existen en la JTable
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        SalirLogin = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtbContactos = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        lblBuscar = new javax.swing.JLabel();
        lblAgregar = new javax.swing.JLabel();
        lblEliminar = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jbtedit = new javax.swing.JButton();
        jbtModificar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtEditNomb = new javax.swing.JTextField();
        txtEditTele = new javax.swing.JTextField();
        txtEditDir = new javax.swing.JTextField();
        txtEditEmail = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(198, 211, 250));
        jPanel1.setPreferredSize(new java.awt.Dimension(1300, 700));
        jPanel1.setRequestFocusEnabled(false);

        SalirLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/logout.png"))); // NOI18N
        SalirLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SalirLoginMouseClicked(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/contact-us.png"))); // NOI18N

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/contactlist_theuser_802.png"))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Cooper Black", 0, 48)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(115, 135, 195));
        jLabel5.setText("Directorio de contactos");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 204, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(44, 44, 44)
                .addComponent(jLabel2)
                .addGap(50, 50, 50))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 48, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addGap(18, 18, 18))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46))
        );

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jtbContactos = new javax.swing.JTable(){
            public boolean isCellEditable(int row, int col){
                return false;
            }
        };
        jtbContactos.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 12)); // NOI18N
        jtbContactos.setForeground(new java.awt.Color(115, 135, 195));
        jtbContactos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NOMBRE", "TELEFONO", "DIRECCION ", "EMAIL"
            }
        ));
        jScrollPane1.setViewportView(jtbContactos);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 609, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(153, 153, 153))
        );

        jPanel4.setBackground(new java.awt.Color(198, 211, 250));
        jPanel4.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(255, 255, 255)));
        jPanel4.setToolTipText("");
        jPanel4.setPreferredSize(new java.awt.Dimension(480, 300));

        jLabel7.setFont(new java.awt.Font("Copperplate Gothic Bold", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(115, 135, 195));
        jLabel7.setText("DATOS DEL CONTACTO");

        jLabel8.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(115, 135, 195));
        jLabel8.setText("NOMBRE");

        jLabel9.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(115, 135, 195));
        jLabel9.setText("TELEFONO");

        jLabel10.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(115, 135, 195));
        jLabel10.setText("DIRECCION");

        jLabel11.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(115, 135, 195));
        jLabel11.setText("EMAIL");

        txtTelefono.setFont(new java.awt.Font("Copperplate Gothic Light", 0, 12)); // NOI18N
        txtTelefono.setPreferredSize(new java.awt.Dimension(100, 20));

        txtNombre.setFont(new java.awt.Font("Copperplate Gothic Light", 0, 12)); // NOI18N
        txtNombre.setPreferredSize(new java.awt.Dimension(100, 20));

        txtDireccion.setFont(new java.awt.Font("Copperplate Gothic Light", 0, 12)); // NOI18N
        txtDireccion.setPreferredSize(new java.awt.Dimension(100, 20));

        txtEmail.setFont(new java.awt.Font("Copperplate Gothic Light", 0, 12)); // NOI18N
        txtEmail.setPreferredSize(new java.awt.Dimension(100, 20));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(90, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addGap(57, 57, 57)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(64, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(198, 211, 250));
        jPanel5.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(255, 255, 255)));

        lblBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/search_find_user_16727.png"))); // NOI18N
        lblBuscar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBuscarMouseClicked(evt);
            }
        });

        lblAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/new_add_user_16734.png"))); // NOI18N
        lblAgregar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblAgregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAgregarMouseClicked(evt);
            }
        });

        lblEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/delete_remove_user_16733.png"))); // NOI18N
        lblEliminar.setText(" ");
        lblEliminar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblEliminarMouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/configure_user_16726.png"))); // NOI18N
        jLabel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(lblBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
                .addGap(12, 12, 12)
                .addComponent(lblAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblBuscar)
                    .addComponent(lblAgregar)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jbtedit.setText("Editar");
        jbtedit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jbteditMouseClicked(evt);
            }
        });
        jbtedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbteditActionPerformed(evt);
            }
        });

        jbtModificar.setText("Modificar");
        jbtModificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jbtModificarMouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(115, 135, 195));
        jLabel4.setText("Telefono :");

        jLabel6.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(115, 135, 195));
        jLabel6.setText("Email :");

        jLabel13.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(115, 135, 195));
        jLabel13.setText("Nombre :");

        jLabel14.setFont(new java.awt.Font("Copperplate Gothic Bold", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(115, 135, 195));
        jLabel14.setText("Direccion :");

        txtEditNomb.setFont(new java.awt.Font("Copperplate Gothic Light", 0, 12)); // NOI18N

        txtEditTele.setEditable(false);
        txtEditTele.setBackground(new java.awt.Color(255, 255, 255));
        txtEditTele.setFont(new java.awt.Font("Copperplate Gothic Light", 0, 12)); // NOI18N

        txtEditDir.setFont(new java.awt.Font("Copperplate Gothic Light", 0, 12)); // NOI18N
        txtEditDir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEditDirActionPerformed(evt);
            }
        });

        txtEditEmail.setFont(new java.awt.Font("Copperplate Gothic Light", 0, 12)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(SalirLogin))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(txtEditTele, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(18, 18, 18)
                                .addComponent(txtEditNomb)))
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel14)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtEditDir)
                            .addComponent(txtEditEmail, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jbtedit)
                        .addGap(26, 26, 26)
                        .addComponent(jbtModificar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 111, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(47, 47, 47))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(81, 81, 81))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SalirLogin)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(82, 82, 82)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel13)
                                    .addComponent(jLabel14)
                                    .addComponent(txtEditNomb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEditDir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(31, 31, 31)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel6)
                                    .addComponent(txtEditTele, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEditEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jbtedit)
                                    .addComponent(jbtModificar))
                                .addGap(18, 18, 18)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SalirLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SalirLoginMouseClicked
        System.exit(0);  //FUNCION PARA SALIR DEL PROGRAMA POR EL ICONO
    }//GEN-LAST:event_SalirLoginMouseClicked

    private void lblAgregarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAgregarMouseClicked

        agregar();
    }//GEN-LAST:event_lblAgregarMouseClicked

    private void lblEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblEliminarMouseClicked

        String nombre = JOptionPane.showInputDialog(null, "Ingrese El Nombre Del Contacto Que Desea Eliminar", "Eliminar Contacto", JOptionPane.INFORMATION_MESSAGE);
        eliminarContacto(nombre);
    }//GEN-LAST:event_lblEliminarMouseClicked

    private void txtEditDirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEditDirActionPerformed

    }//GEN-LAST:event_txtEditDirActionPerformed

    private void jbteditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jbteditMouseClicked

        editarContacto();
    }//GEN-LAST:event_jbteditMouseClicked

    private void jbtModificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jbtModificarMouseClicked

        modificar();
    }//GEN-LAST:event_jbtModificarMouseClicked

    private void lblBuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBuscarMouseClicked

        String nombre = JOptionPane.showInputDialog(null, "Ingrese El Nombre Del Contacto Que Desea Eliminar", "Eliminar Contacto", JOptionPane.INFORMATION_MESSAGE);
        buscarContacto(nombre);

    }//GEN-LAST:event_lblBuscarMouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked

        JOptionPane.showMessageDialog(null, "Contactos Guardados : " + contactos.size(), "Informacion  Del Directorio", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jbteditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbteditActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbteditActionPerformed

    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Directorio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Directorio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Directorio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Directorio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Directorio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel SalirLogin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbtModificar;
    private javax.swing.JButton jbtedit;
    private javax.swing.JTable jtbContactos;
    private javax.swing.JLabel lblAgregar;
    private javax.swing.JLabel lblBuscar;
    private javax.swing.JLabel lblEliminar;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtEditDir;
    private javax.swing.JTextField txtEditEmail;
    private javax.swing.JTextField txtEditNomb;
    private javax.swing.JTextField txtEditTele;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
